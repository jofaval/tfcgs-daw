# Summary

Date : 2020-04-02 10:44:04

Directory c:\Users\PAS\Desktop\ProyectoDAW\App

Total : 124 files,  44245 codes, 868 comments, 3674 blanks, all 48787 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JavaScript | 29 | 26,622 | 279 | 634 | 27,535 |
| CSS | 18 | 10,635 | 101 | 1,744 | 12,480 |
| PHP | 56 | 4,439 | 361 | 969 | 5,769 |
| HTML | 20 | 2,520 | 127 | 316 | 2,963 |
| Markdown | 1 | 29 | 0 | 11 | 40 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 124 | 44,245 | 868 | 3,674 | 48,787 |
| client | 68 | 39,842 | 553 | 2,745 | 43,140 |
| client\HTMLComponents | 18 | 2,109 | 127 | 293 | 2,529 |
| client\HTMLComponents\tests | 6 | 269 | 0 | 35 | 304 |
| client\scripts | 29 | 26,622 | 279 | 634 | 27,535 |
| client\scripts\js | 20 | 2,838 | 221 | 567 | 3,626 |
| client\scripts\libs | 8 | 23,740 | 58 | 62 | 23,860 |
| client\scripts\webcomponents | 1 | 44 | 0 | 5 | 49 |
| client\styles | 19 | 10,708 | 109 | 1,752 | 12,569 |
| server | 54 | 3,996 | 315 | 898 | 5,209 |
| server\classes | 27 | 2,719 | 297 | 792 | 3,808 |
| server\classes\POPOs | 19 | 1,561 | 146 | 558 | 2,265 |
| server\libs | 6 | 244 | 16 | 31 | 291 |
| server\templates | 17 | 860 | 2 | 71 | 933 |
| server\templates\forms | 1 | 33 | 0 | 3 | 36 |

[details](details.md)