$(window).on("load", function () {
    $(document.body).removeClass("text-light");
    $(document.body).addClass("text-dark");
    $(".hiddendiv.common").remove();
});