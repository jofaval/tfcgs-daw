<?php

$reportErrors = true;

require_once __DIR__ . '/../server/classes/Config.php';
require_once __DIR__ . '/../server/libs/bExceptions.php';
require_once __DIR__ . '/../server/libs/bFile.php';
require_once __DIR__ . '/../server/libs/bDate.php';
require_once __DIR__ . '/../server/libs/bCrypt.php';
require_once __DIR__ . '/../server/libs/bEmail.php';
require_once __DIR__ . '/../server/libs/utils.php';
require_once __DIR__ . '/../server/classes/Sessions.php';
require_once __DIR__ . '/../server/classes/Validation.php';
require_once __DIR__ . '/../server/classes/Model.php';
require_once __DIR__ . '/../server/classes/Controller.php';
require_once __DIR__ . '/../server/classes/AjaxController.php';

error_reporting($reportErrors ? 1 : 0);

/* $conexion = new PDO('mysql:host=' . Config::$mvc_bd_hostname . ';dbname=' . Config::$mvc_bd_nombre . '', Config::$mvc_bd_usuario, Config::$mvc_bd_clave);
// Realiza el enlace con la BD en utf-8
$conexion->exec("set names utf8");
$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$controller = new Controller();
$model = new Model(); */

//Session test
session_start();
$_SESSION["username"] = time() + 15;
var_dump($_SESSION["username"] - time());

/* echo "<h1>Métodos</h1>";
$methods = get_class_methods('Controller');
var_dump($methods);
echo "<pre>";
foreach ($methods as $method) {
echo "'$method' => array('controller' => 'Controller', 'action' => '$method', 'access' => Config::\$ACCESS_LEVEL_GUEST),<br />";
}
echo "</pre>"; */

/* $conexion->beginTransaction();
try {
$insert = 'Insert Into `clients` (`first_name`, `second_name`, `email`)
Values ("Pepe", "Fabra Valverde", "agewe@wgwegweg.com")';

$queryVar = $conexion->prepare($insert);
$queryVar->execute();
$stmt = $conexion->query("SELECT LAST_INSERT_ID()");
$lastId = $stmt->fetchColumn();
echo $lastId;
$conexion->commit();
} catch (\Throwable $th) {
$conexion->rollBack();
echo "error";
} */

//Prueba de login con contraseña
/* $actual = Cryptography::blowFishCrypt("test", "jofaval");
$deBaseDeDatos = $conexion->query("select * from users where username = 'jofaval'")->fetchAll(PDO::FETCH_ASSOC)[0]["password"];
echo $actual;
echo "<br>";
echo $deBaseDeDatos;
echo "<br>";
var_dump($actual == $deBaseDeDatos); */

/* $_REQUEST["username"] = "jofaval";
$_REQUEST["password"] = "test";
$_REQUEST["signin"] = "ewgweg";
Utils::varDumpData($controller->signin()); */

/* //Hacer inserts

$inserts = [
'INSERT INTO schedules (orderId, startHour, endHour, year) VALUES (1, "7:55", "8:50", "2019-02-02")',
]; */

/* foreach ($inserts as $insert) {
$queryVar = $conexion->prepare($insert);
$queryVar->execute();
} */

/* //Hacer consultas

$controller = new Controller();
$conexion = new PDO('mysql:host=' . Config::$mvc_bd_hostname . ';dbname=' . Config::$mvc_bd_nombre . '', Config::$mvc_bd_usuario, Config::$mvc_bd_clave);
// Realiza el enlace con la BD en utf-8
$conexion->exec("set names utf8");
$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$string = "SELECT * FROM dataTable";

$queryVar = $conexion->prepare($string);

$params = [
];

echo "<br><br>";
$queryVar->execute(); //$params

echo "<table border='1'>";
$queryResult = $queryVar->fetchAll(PDO::FETCH_ASSOC);
foreach ($queryResult as $row) {
echo "<tr>";
foreach ($row as $column) {
echo "<td>";
var_dump($column);
echo "</td>";
}
echo "</tr>";
}
echo "</table>"; */