<?php

$map['accessLevel'] = array('controller' => 'Controller', 'action' => 'accessLevel', 'access' => Config::$ACCESS_LEVEL_GUEST);